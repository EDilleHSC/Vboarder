# TODO: Define tone, personality, and perspective.
