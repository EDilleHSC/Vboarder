#!/usr/bin/env python3
"""
AAGENT_DIR_NAME = "."  # current base directory#!/usr/bin/env python3
"""
ask.py — CLI tool to query a local agent
"""
import argparse
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

# --- Configuration ---
# Define required and optional configuration files
AGENT_FILES = {
    "required": ["agent.json", "prompt.md", "persona.md"],
    "optional": ["config.json", "schedule.json"]
}
LOG_FILE_NAME = "memory.jsonl"
AGENT_DIR_NAME = "."  # ← This is the fix to use the current directory!
"""ask.py - CLI tool to query a local agent"""


import argparse
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

# --- Configuration ---
# Define required and optional configuration files
AGENT_FILES = {
    "required": ["agent.json", "prompt.md", "persona.md"],
    "optional": ["config.json", "schedule.json"]
}
LOG_FILE_NAME = "memory.jsonl"
AGENT_DIR_NAME = "agents"

# --- Utility Functions ---

def load_text_file(path: Path) -> str:
    """Safely loads text from a file, handling UTF-8 BOM."""
    try:
        # Using 'utf-8-sig' to strip the common Byte Order Mark (BOM)
        return path.read_text(encoding='utf-8-sig')
    except Exception as e:
        print(f"⚠️ Warning: Could not read {path}: {e}")
        return ""

def load_json_file(path: Path) -> Dict[str, Any]:
    """Safely loads JSON data from a file."""
    text = load_text_file(path)
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        print(f"❌ Error: Invalid JSON in {path}: {e}")
        # Terminate if a core JSON file (like agent.json) is malformed
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error reading JSON file {path}: {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Ask an agent a question")
    parser.add_argument("--agent", required=True, help="Agent name (folder name)")
    parser.add_argument("--query", required=True, help="Your question to the agent")
    args = parser.parse_args()

    # --- 1. Path Resolution and Validation ---
    # Path is resolved relative to the script's location
    base_dir = Path(__file__).resolve().parent.parent
    agent_path = base_dir / AGENT_DIR_NAME / args.agent

    if not agent_path.is_dir():
        print(f"❌ Error: Agent folder not found: {agent_path}")
        sys.exit(1)
    
    # --- 2. Load Agent Files ---
    agent_data = {}
    
    # Load required files
    for name in AGENT_FILES["required"]:
        file_path = agent_path / name
        if not file_path.is_file():
             print(f"❌ Error: Required file missing for agent {args.agent}: {file_path}")
             sys.exit(1)
             
        if name.endswith('.json'):
            agent_data[name.replace('.json', '')] = load_json_file(file_path)
        else:
            agent_data[name.replace('.md', '')] = load_text_file(file_path)

    # Load optional files
    for name in AGENT_FILES["optional"]:
        file_path = agent_path / name
        if file_path.is_file():
            if name.endswith('.json'):
                agent_data[name.replace('.json', '')] = load_json_file(file_path)
            else:
                agent_data[name.replace('.md', '')] = load_text_file(file_path)
    
    # --- 3. Execution (Simulated) ---
    agent_name = agent_data['agent'].get('role', args.agent) if 'agent' in agent_data else args.agent
    
    print(f"\n🧠 [{agent_name}] Prompt:\n{agent_data['prompt'][:500]}\n...")
    print(f"\n🗣️ You: {args.query}")

    # Simulated response (placeholder)
    response = f"Simulated response from {agent_name} based on prompt/persona/context."
    print(f"🤖 {agent_name}: {response}\n")

    # --- 4. Log the Query and Response ---
    log_path = agent_path / LOG_FILE_NAME
    entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z", # Use Z suffix for UTC
        "agent": agent_name,
        "query": args.query,
        "response": response
    }
    try:
        # Use 'a' mode for append, 'utf-8-sig' for consistent logging
        with open(log_path, 'a', encoding='utf-8-sig') as logf:
            logf.write(json.dumps(entry) + "\n")
        print(f"📝 Logged entry to: {log_path}")
    except Exception as e:
        print(f"❌ Error logging to {log_path}: {e}")

if __name__ == "__main__":
    main()
